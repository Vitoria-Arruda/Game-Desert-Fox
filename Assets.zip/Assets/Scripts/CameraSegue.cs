using System.Transactions; // Importa a biblioteca para transações (não está sendo usada no código, pode ser removida)
using UnityEngine;

public class NewMonoBehaviourScript : MonoBehaviour
{
    // Referência ao objeto "player", que é o objeto cuja posição será seguida
    public Transform player;

    // Valores de limite para a posição do objeto em X (controle de movimentação ao longo do eixo X)
    public float minX, maxX;

    // Tempo de interpolação para o movimento suave entre as posições
    public float timeLerp;

    // Método chamado a cada quadro fixo (geralmente para movimentos ou física)
    void FixedUpdate()
    {
        // Calcula a nova posição que o objeto deve alcançar, com base na posição do player
        // A posição no eixo Z é ajustada para ficar 10 unidades atrás do player
        Vector3 newPosition = player.position + new Vector3(0, 0, -10);

        // Define a posição Y do objeto para um valor fixo (0.1), mantendo o movimento plano no eixo XZ
        newPosition.y = 0.1f;

        // Aplica a interpolação linear entre a posição atual do objeto e a nova posição
        // Isso cria um movimento suave entre os dois pontos
        newPosition = Vector3.Lerp(transform.position, newPosition, timeLerp);

        // Atualiza a posição do objeto para a nova posição calculada
        transform.position = newPosition;

        // Garante que o objeto não ultrapasse os limites definidos para a posição X
        // A função Mathf.Clamp limita o valor de transform.position.x entre minX e maxX
        transform.position = new Vector3(Mathf.Clamp(transform.position.x, minX, maxX), transform.position.y, transform.position.z);
    }
}
