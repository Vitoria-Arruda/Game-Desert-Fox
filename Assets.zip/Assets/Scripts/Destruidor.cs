using UnityEngine;

public class Destruidor : MonoBehaviour
{
    // Método chamado quando um objeto entra em colisão com o trigger 2D do objeto atual
    void OnTriggerEnter2D(Collider2D collision)
    {
        // Verifica se o objeto que entrou em colisão tem a tag "Player"
        if(collision.gameObject.CompareTag("Player"))
        {
            // Obtém o componente PlayerVida do objeto "Player" e chama o método PerderVida() para reduzir a vida
            collision.GetComponent<PlayerVida>().PerderVida();
        }
    }
}
