using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    // Instância estática para garantir que exista apenas um GameController durante o jogo
    public static GameController gc;
    
    // Referências para os textos da UI
    public Text textoMoeda;
    public int moedas;
    public int moedasCheckpoint;

    public Text textoVida;
    public int vidas = 3;

    public GameObject textNextLevel;

    // Método chamado quando o script é carregado
    void Awake()
    {
        // Verifica se já existe uma instância do GameController
        if (gc == null)
        {
            gc = this; // Se não, define a instância como a atual
            DontDestroyOnLoad(gameObject); // Impede que o GameController seja destruído ao carregar novas cenas
        }
        else if (gc != this)
        {
            Destroy(gameObject); // Se já existir outra instância, destrói a atual
        }

        // Atualiza os textos da UI com as informações iniciais
        AtualizarTela();
    }

    // Método para adicionar ou subtrair vidas
    public void DefinirVidas(int vida)
    {
        vidas += vida; // Altera o número de vidas
        if (vidas >= 0) // Garante que o número de vidas não será negativo
            AtualizarTela(); // Atualiza a tela com a nova quantidade de vidas
    }

    // Método para atualizar os textos da UI
    public void AtualizarTela()
    {
        textoMoeda.text = moedas.ToString(); // Atualiza o texto da moeda
        textoVida.text = vidas.ToString(); // Atualiza o texto das vidas

        VerificarVitoria(); // Verifica se as condições para vencer foram atendidas
    }

    // Método para verificar se o jogador venceu
    private void VerificarVitoria()
    {
        // Se estiver na cena "Lvl2" e o jogador tiver 8 ou mais moedas, vence o nível
        if (SceneManager.GetActiveScene().name == "Lvl2" && moedas >= 8)
        {
            // Chama o método para carregar a cena de vitória após 1 segundo
            Invoke("CarregarCenaVitoria", 1f);
        }
    }

    // Método para carregar a cena de vitória
    private void CarregarCenaVitoria()
    {
        // Carrega a cena de vitória
        SceneManager.LoadScene("Vitoria");

        // Chama o método para voltar ao Menu após 3 segundos (ajuste o tempo conforme necessário)
        Invoke("VoltarParaMenu", 3f);
    }

    // Método para voltar para o Menu principal e resetar o estado do jogo
    private void VoltarParaMenu()
    {
        // Carrega a cena "Menu"
        SceneManager.LoadScene("Menu");

        // Reseta as variáveis do jogo para o estado inicial
        GameController.gc.vidas = 3;
        GameController.gc.moedas = 0;
        GameController.gc.moedasCheckpoint = 0;

        // Atualiza a tela para refletir o estado inicial
        GameController.gc.AtualizarTela();
    }
}
