using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class Inimigo : MonoBehaviour
{
    // Velocidade de movimento do inimigo
    public float speed;

    // Verifica se o inimigo está em contato com o chão
    public bool ground = true;

    // Posição usada para verificar se o inimigo está no chão
    public Transform groundCheck;

    // Layer do chão, usado para verificar colisões com o chão
    public LayerMask groundLayer;

    // Direção em que o inimigo está voltado (direita ou esquerda)
    public bool facingRight = true;

    // Método chamado quando o script é iniciado
    void Start()
    {
        // Nenhuma inicialização necessária no momento
    }

    // Método chamado a cada quadro
    void Update()
    {
        // Move o inimigo para a direita constantemente
        transform.Translate(Vector2.right * speed * Time.deltaTime);

        // Verifica se o inimigo está em contato com o chão usando Linecast
        ground = Physics2D.Linecast(groundCheck.position, transform.position, groundLayer);
        Debug.Log(ground); // Exibe se o inimigo está no chão ou não no console

        // Se o inimigo não estiver no chão, inverte a direção
        if (ground == false)
        {
            speed *= -1; // Inverte a direção do movimento
        }
    }

    // Método para inverter a direção em que o inimigo está olhando
    void Flip()
    {
        facingRight = !facingRight; // Alterna a direção do inimigo
        Vector3 Scale = transform.localScale; // Obtém a escala atual do inimigo
        Scale.x *= -1; // Inverte a escala no eixo X para mudar a direção
        transform.localScale = Scale; // Aplica a nova escala
    }

    // Método chamado quando o inimigo colide com outro objeto
    void OnCollisionEnter2D(Collision2D collision)
    {
        // Verifica se o objeto que colidiu com o inimigo é o player
        if (collision.gameObject.tag == "Player")
        {
            Player player = collision.gameObject.GetComponent<Player>();

            // Verifica se o player pode matar o inimigo (se possui um item específico)
            if (player.PodeMatarInimigo)
            {
                Debug.Log("Inimigo destruído pelo item coletado!");
                Destroy(gameObject); // Destrói o inimigo
                player.PodeMatarInimigo = false; // Reseta a capacidade de matar o inimigo
            }
            else
            {
                // Se o player não pode matar o inimigo, perde uma vida
                collision.gameObject.GetComponent<PlayerVida>().PerderVida();
            }
        }
    }
}
