using UnityEngine;

public class ItemColetavel : MonoBehaviour
{
    // Tag do inimigo, usada para comparar com os objetos no jogo
    public string inimigoTag = "Inimigo";

    // Método chamado quando um objeto entra no trigger 2D do item coletável
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Exibe no console o nome do objeto que entrou no trigger
        Debug.Log("Algo entrou no trigger" + collision.gameObject.name);

        // Verifica se o objeto que entrou no trigger é o jogador
        if(collision.gameObject.CompareTag("Player"))
        {
            // Exibe no console que o item foi coletado e que os inimigos podem ser destruídos
            Debug.Log("Item coletado! Inimigos podem ser destruídos.");

            // Ativa a capacidade do jogador de matar inimigos
            collision.gameObject.GetComponent<Player>().PodeMatarInimigo = true;

            // Destroi o item coletável após ser coletado
            Destroy(gameObject);
        }
    }
}
