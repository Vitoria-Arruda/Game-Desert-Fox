using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    // Método responsável por carregar uma cena específica e ajustar as variáveis do GameController
    public void LoadScenes(string cena)
    {
        // Carrega a cena passada como argumento
        SceneManager.LoadScene(cena);

        // Ativa o áudio de fundo (supondo que o MusicPlayer tenha um componente AudioSource)
        GameObject.Find("MusicPlayer").GetComponent<AudioSource>().enabled = true;

        // Se a cena carregada for o MenuPrincipal, reinicia as variáveis de vida e moedas
        if (cena == "MenuPrincipal") 
        {
            GameController.gc.vidas = 3;
            GameController.gc.moedas = 0;
        }
        else
        {
            // Para as outras cenas, mantém as vidas do jogador (não reseta as vidas)
            GameController.gc.vidas = 3; // Mantém vidas para novas fases
        }
    }

    // Método para retornar para uma cena, desativando a música de fundo
    public void ButtonReturn(string cena)
    {
        // Carrega a cena passada como argumento
        SceneManager.LoadScene(cena);

        // Desativa o áudio de fundo ao sair da cena
        GameObject.Find("MusicPlayer").GetComponent<AudioSource>().enabled = false;
    }

    // Método para fechar o aplicativo
    public void Quit()
    {
        // Encerra o aplicativo (apenas funciona em builds de aplicativo)
        Application.Quit();
    }
}
