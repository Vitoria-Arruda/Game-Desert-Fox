using UnityEngine;

public class MusicController : MonoBehaviour
{
    // Instância estática do MusicController para garantir que só haja um controlador de música
    private static MusicController mC;

    // Método chamado ao inicializar o objeto
    private void Awake()
    {
        // Verifica se a instância do MusicController ainda não foi definida
        if(mC == null)
        {
            mC = this; // Define esta instância como a única instância do MusicController
            DontDestroyOnLoad(gameObject); // Garante que o objeto não seja destruído ao carregar novas cenas
        }
        else if(mC != this)
        {
            // Se já houver uma instância do MusicController, destrói esta instância para evitar duplicação
            Destroy(gameObject);
        }
    }
}
