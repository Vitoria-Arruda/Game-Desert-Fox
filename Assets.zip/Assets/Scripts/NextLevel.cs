using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour
{
    // Áudio de fim de fase
    public AudioClip finish;

    // Fonte de áudio usada para tocar o áudio de fim de fase
    public AudioSource audioS;

    // Método chamado ao iniciar o script
    void Start()
    {
        // No momento, o Start está vazio, mas pode ser útil para inicializações futuras
    }

    // Método chamado logo após a instância do objeto ser carregada
    void Awake()
    {
        // Garante que o objeto não seja destruído ao carregar novas cenas (por exemplo, o MusicPlayer)
        DontDestroyOnLoad(gameObject);
    }

    // Método chamado quando um objeto entra no trigger (caixa de colisão)
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Verifica se o objeto que entrou no trigger é o jogador
        if(collision.CompareTag("Player"))
        {
            // Se o jogador coletou todas as moedas (12 moedas)
            if(GameController.gc.moedas == 12)
            {
                // Ativa a tela de "Próximo nível"
                GameController.gc.textNextLevel.SetActive(true);

                // Para a música de fundo
                GameObject.Find("MusicPlayer").GetComponent<AudioSource>().Stop();

                // Desabilita o controle do jogador e zera a velocidade do Rigidbody
                collision.GetComponent<Player>().enabled = false;
                collision.GetComponent<Rigidbody2D>().linearVelocity = Vector2.zero;

                // Ajusta o animador para exibir a animação de idle (inatividade)
                collision.GetComponent<Animator>().SetBool("walk", false);
                collision.GetComponent<Animator>().Play("Player_idle");

                // Toca o som de fim de fase
                GetComponent<AudioSource>().clip = finish;
                GetComponent<AudioSource>().Play();

                // Chama o método NextScenes após 5 segundos para permitir tempo de animação ou transição
                Invoke("NextScenes", 5f);
            }
            else
            {
                // Exibe uma mensagem de que o jogador precisa coletar todas as moedas
                Debug.Log("VocÊ precisa coletar todas as moedas para passar para a próxima fase.");
            }
        }
    }

    // Método que carrega a próxima cena e reseta variáveis relevantes
    void NextScenes()
    {
        // Atualiza o checkpoint de moedas antes de mudar de cena
        GameController.gc.moedasCheckpoint = GameController.gc.moedas;

        // Carrega a próxima cena baseada no índice atual
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);

        // Desativa a tela de "Próximo nível"
        GameController.gc.textNextLevel.SetActive(false);

        // Reativa a música de fundo após a transição de cena
        GameObject.Find("MusicPlayer").GetComponent<AudioSource>().Play();
    }
}
