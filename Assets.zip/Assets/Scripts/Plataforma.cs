using UnityEngine;

public class Plataforma : MonoBehaviour
{
    // A velocidade de movimento da plataforma, ajustável no inspetor
    public float moveSpeed = 2f;

    // Um flag para controlar se a plataforma está em movimento
    public bool plataforma;

    // Flag para determinar se a plataforma deve se mover para cima
    public bool moveUp = true;

    // Atualização a cada quadro
    void Update()
    {
        // Se a plataforma ultrapassar o limite superior (Y > 3), ela começa a descer
        if(transform.position.y > 3)
        {
            moveUp = false;
        }
        // Se a plataforma ultrapassar o limite inferior (Y < -1.64f), ela começa a subir
        else if(transform.position.y < -1.64f)
        {
            moveUp = true;
        }

        // Caso a flag moveUp seja verdadeira, a plataforma se move para cima
        if(moveUp)
        {
            transform.Translate(Vector2.up * moveSpeed * Time.deltaTime);
        }
        // Caso contrário, ela se move para baixo
        else
        {
            transform.Translate(Vector2.up * -moveSpeed * Time.deltaTime);
        }
    }
}
