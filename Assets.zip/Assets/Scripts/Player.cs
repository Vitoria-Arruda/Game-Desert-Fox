using UnityEngine;
using UnityEngine.Rendering;

public class Player : MonoBehaviour
{
    // Flags e variáveis relacionadas ao jogador
    public bool PodeMatarInimigo = false; // Define se o jogador pode matar inimigos
    private Animator playerAnim; // Referência ao Animator para controlar animações
    private Rigidbody2D rbPlayer; // Referência ao Rigidbody2D do jogador para controlar o movimento
    public float speed; // Velocidade de movimento do jogador
    private SpriteRenderer sr; // Referência ao SpriteRenderer do jogador para manipular a direção da sprite
    public float forcaPulo; // Força do pulo do jogador
    public bool noChao; // Verifica se o jogador está no chão
    public bool puloDuplo; // Verifica se o jogador pode dar um pulo duplo
    public bool puloTriplo; // Verifica se o jogador pode dar um pulo triplo
    private GameController gcPlayer; // Referência ao GameController, que gerencia as variáveis globais do jogo

    // Referências para os efeitos sonoros
    public AudioSource audioS;
    public AudioClip[] Sounds; // Array de clips de áudio para diferentes sons no jogo

    void Start()
    {
        // Inicializando variáveis do GameController e referências
        gcPlayer = GameController.gc;
        gcPlayer.moedas = 0;
        playerAnim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
        rbPlayer = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        // Movimentação do jogador é controlada no FixedUpdate para garantir uma movimentação mais suave
        MovePlayer();
    }

    void Update()
    {
        // Verifica e processa o pulo do jogador no Update
        Jump();
    }

    // Função que controla o movimento horizontal do jogador
    void MovePlayer()
    {
        float movimentoHorizontal = Input.GetAxisRaw("Horizontal");

        // Atualiza a velocidade horizontal do jogador no Rigidbody2D
        rbPlayer.linearVelocity = new Vector2(movimentoHorizontal * speed, rbPlayer.linearVelocity.y);

        // Altera a direção da animação e a orientação da sprite com base no movimento
        if (movimentoHorizontal > 0 ) 
        {
            playerAnim.SetBool("walk", true);
            sr.flipX = false; // Player vira para a direita
        }
        else if (movimentoHorizontal < 0 )
        {
            playerAnim.SetBool("walk", true);
            sr.flipX = true; // Player vira para a esquerda
        }
        else
        {
            playerAnim.SetBool("walk", false); // Para a animação quando não há movimento horizontal
        }
    }

    // Função que controla o pulo do jogador
    void Jump()
    {
        // Verifica se o botão de pulo foi pressionado
        if (Input.GetButtonDown("Jump"))
        {
            if(noChao) // Pulo normal
            {
                audioS.clip = Sounds[1];
                audioS.Play();
                rbPlayer.linearVelocity = Vector2.zero; // Zera a velocidade vertical para garantir um pulo preciso
                playerAnim.SetBool("jump", true); // Inicia animação de pulo
                rbPlayer.AddForce(new Vector2(0, forcaPulo), ForceMode2D.Impulse); // Aplica a força do pulo
                noChao = false; // Indica que o jogador não está mais no chão
                puloDuplo = true; // Permite o pulo duplo
            }
            else if (!noChao && puloDuplo) // Pulo duplo
            {
                audioS.clip = Sounds[1];
                audioS.Play();
                rbPlayer.linearVelocity = Vector2.zero; // Zera a velocidade vertical
                playerAnim.SetBool("jump", true); // Animação de pulo
                rbPlayer.AddForce(new Vector2(0, forcaPulo), ForceMode2D.Impulse); // Aplica força do pulo
                noChao = false; // Jogador ainda não está no chão
                puloDuplo = false; // Impede mais pulos duplos
                puloTriplo = true; // Permite o pulo triplo
            }
            else if (!noChao && puloTriplo) // Pulo triplo
            {
                audioS.clip = Sounds[1];
                audioS.Play();
                rbPlayer.linearVelocity = Vector2.zero; // Zera a velocidade vertical
                playerAnim.SetBool("jump", true); // Animação de pulo
                rbPlayer.AddForce(new Vector2(0, forcaPulo), ForceMode2D.Impulse); // Aplica a força do pulo
                noChao = false; // Jogador ainda não está no chão
                puloDuplo = false; // Não permite pulo duplo
                puloTriplo = false; // Não permite mais pulo triplo
            }
        }
    }

    // Função chamada quando o jogador entra em colisão com o chão
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 6) // Verifica se o jogador colidiu com o chão
        {
            playerAnim.SetBool("jump", false); // Desativa a animação de pulo
            noChao = true; // Jogador está no chão
            puloDuplo = false; // Impede pulo duplo
            puloTriplo = false; // Impede pulo triplo
        }

        if(collision.gameObject.tag == "Plataforma") // Se o jogador está em uma plataforma móvel
        {
            gameObject.transform.parent = collision.transform; // Faz o jogador seguir a plataforma
        }
    }

    // Função chamada quando o jogador sai de uma plataforma
    void OnCollisionExit2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Plataforma")
        {
            gameObject.transform.parent = null; // Desvincula o jogador da plataforma
        }
    }

    // Função chamada quando o jogador entra em contato com um "trigger" (gatilho)
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Coleta uma moeda
        if (collision.gameObject.tag == "Coins")
        {
            audioS.clip = Sounds[0]; // Som de coleta
            audioS.Play();
            Destroy(collision.gameObject); // Remove a moeda
            gcPlayer.moedas++; // Incrementa o número de moedas
            GameController.gc.AtualizarTela(); // Atualiza a tela do controlador do jogo
        }

        // Colisão com inimigo
        if(collision.gameObject.tag == "Inimigo")
        {
            audioS.clip = Sounds[2]; // Som de colisão com inimigo
            audioS.Play();
            rbPlayer.linearVelocity = Vector2.zero; // Zera a velocidade para interromper o movimento
            rbPlayer.AddForce(Vector2.up * 5, ForceMode2D.Impulse); // Empurra o jogador para cima para simular dano
            collision.gameObject.GetComponent<SpriteRenderer>().flipY = true; // Vira o inimigo de cabeça para baixo
            collision.gameObject.GetComponent<Inimigo>().enabled = false; // Desabilita o inimigo
            collision.gameObject.GetComponent<CapsuleCollider2D>().enabled = false; // Desabilita o collider do inimigo
            collision.gameObject.GetComponent<BoxCollider2D>().enabled = false; // Desabilita outro collider do inimigo
            collision.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic; // Torna o inimigo estático
            Destroy(collision.gameObject, 1f); // Destrói o inimigo após 1 segundo
        }
    }
}
