using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerVida : MonoBehaviour
{
    public bool vivo = true; // Flag para verificar se o jogador está vivo

    void Start()
    {
        // Função de inicialização (não está sendo usada no momento)
    }

    // Função chamada quando o jogador perde vida
    public void PerderVida()
    {
        if (vivo) // Verifica se o jogador ainda está vivo
        {
            // Toca o som de morte do jogador
            GetComponent<Player>().audioS.clip = GetComponent<Player>().Sounds[3];
            GetComponent<Player>().audioS.Play();
            
            vivo = false; // Marca o jogador como morto
            gameObject.GetComponent<Animator>().SetTrigger("dead"); // Ativa a animação de morte
            gameObject.GetComponent<Rigidbody2D>().linearVelocity = Vector2.zero; // Zera a velocidade do jogador para parar o movimento
            gameObject.GetComponent<CapsuleCollider2D>().enabled = false; // Desabilita o collider para impedir colisões
            gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic; // Torna o corpo do jogador estático
            gameObject.GetComponent<Player>().enabled = false; // Desabilita os controles do jogador (não permite mais movimentação)
            gameObject.GetComponent<Animator>().SetBool("jump", false); // Para a animação de pulo, caso esteja em execução

            // Decrementa as vidas no GameController
            GameController.gc.DefinirVidas(-1);

            // Verifica se o jogador ainda tem vidas e decide qual ação tomar
            if (GameController.gc.vidas >= 0)
            {
                // Se o jogador ainda tem vidas, reinicia a fase após 1 segundo
                Invoke("LoadScene", 1f);
            }
            else
            {
                // Se o jogador não tem mais vidas, vai para a tela de Game Over após 1 segundo
                Invoke("LoadGameOver", 1f);
            }
        }
    }

    // Função chamada para carregar a cena de Game Over
    public void LoadGameOver()
    {
        // Desabilita o áudio de música de fundo
        GameObject.Find("MusicPlayer").GetComponent<AudioSource>().enabled = false;

        // Carrega a cena de "Game Over"
        SceneManager.LoadScene("Game Over");

        // Zera as variáveis relacionadas ao progresso do jogo
        GameController.gc.vidas = 0;
        GameController.gc.moedas = 0;
        GameController.gc.moedasCheckpoint = 0;

        // Atualiza a tela com as novas informações
        GameController.gc.AtualizarTela();
    }

    // Função chamada para reiniciar a fase atual após o jogador perder vida
    void LoadScene()
    {
        // Obtém o nome da cena atual
        string cenaAtual = SceneManager.GetActiveScene().name;

        // Se a fase for a primeira, as moedas são zeradas
        if (cenaAtual == "Lvl1")
        {
            GameController.gc.moedas = 0;
        }
        else
        {
            // Se for uma fase subsequente, as moedas são restauradas para o valor do checkpoint
            GameController.gc.moedas = GameController.gc.moedasCheckpoint;
        }

        // Atualiza a tela com as novas informações
        GameController.gc.AtualizarTela();

        // Carrega a cena atual novamente
        SceneManager.LoadScene(cenaAtual);
    }
}
